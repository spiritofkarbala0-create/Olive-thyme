# Olive & Thyme: photo and asset list

All images live in `assets/images/`. To replace one, keep the same file name (or change the path in `assets/js/content.js`). A missing file shows a styled placeholder, never a broken image.

## Original Olive & Thyme assets (supplied by the restaurant)

| File | Used in | Source |
|---|---|---|
| `logo.png`, `logo-mark.png` | Header (olive version) | Extracted from the 3D wall-logo mockup |
| `logo-light.png`, `logo-light-mark.png` | Footer (cream version) | Same as above, recoloured |
| `story.jpg`, `story-detail.jpg`, `gallery-3.jpg`, `gallery-5.jpg` | Our Story, Gallery | Interior / table photo ("NOW OPEN" text cropped out) |
| `experience.jpg`, `gallery-1.jpg` | Experience, Gallery | Storefront at night |
| `gallery-2.jpg` | Gallery | Round hanging sign |
| `gallery-4.jpg` | Gallery | 3D wall-logo mockup |

**Logo:** the logo was lifted from a photo of a 3D sign, so the edges are slightly soft. If the designer has the original vector file (SVG, AI, EPS or PDF) or a transparent PNG, drop it in as `logo.png` / `logo-mark.png` for a sharper result.

## Temporary stock food photos (Unsplash, free licence)

These are **illustrative only**, not photos of Olive & Thyme dishes. The site says so under the menu ("Dish photographs are illustrative"), and the menu is labelled "Sample menu". Replace them with photos of your real dishes as soon as you can (top-down, round plate, about 1000×1000; a transparent PNG is ideal).

| File | Used in | Unsplash photo |
|---|---|---|
| `hero-dish.webp` | Hero plate | https://unsplash.com/photos/a-plate-of-food-MbFkgRWLCx0 |
| `menu-salads.webp` | Menu: Starters & Salads | https://unsplash.com/photos/gourmet-dish-with-roasted-potatoes-and-shredded-cheese-_V7MPFwNpJE |
| `menu-mains.webp` | Menu: Mains | https://unsplash.com/photos/cooked-meat-on-white-ceramic-plate-Xt4yZUIpRTo |
| `menu-grill.webp` | Menu: From the Grill | images.unsplash.com/photo-1763219802762-1d34ee0907c5 |
| `menu-pasta.webp` | Menu: Pasta | https://unsplash.com/photos/a-colorful-pasta-dish-with-vegetables-and-olives-3yhkCoP0plE |

The Unsplash License allows free commercial use without attribution. Each plate was cropped to a circle so it sits on the page like a cut-out.

## Still needed before launch

- **The real menu:** dish names, descriptions and (optionally) prices. The Google Maps profile shows no menu yet. Once entered, set `sample: false` in content.js; this also removes the "illustrative" note.
- **Photos of your own dishes** to replace the five stock plates above.
- **Opening hours:** add them to `hours` in content.js. The Hours row appears automatically.
- **WhatsApp:** confirm whether +92 311 1333722 takes WhatsApp, then set `whatsappHref`.
- **Social links:** an Instagram account `oliveandthyme.pk` appears in Google results. Confirm it is yours and add it to `social` in content.js, plus Facebook if wanted.
- **Online booking:** reservations are by phone only until a booking form is connected to a real service.
