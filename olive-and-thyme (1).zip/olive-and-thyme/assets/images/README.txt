Photos used by the site. See ../../ASSETS.md for sources and replacement sizes.
