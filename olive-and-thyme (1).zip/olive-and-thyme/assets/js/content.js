/* =====================================================================
   OLIVE & THYME — SITE CONTENT
   ---------------------------------------------------------------------
   This is the only file you need to edit to change restaurant details,
   menu items and photos. Everything on the page reads from here.

   PHOTOS
   - Put image files in /assets/images/ using the file names below
     (or change the paths). If a file is missing, the site shows an
     elegant placeholder instead of a broken image.
   - "cutout: true" slots expect a transparent PNG/WebP of a plate or
     ingredient. Plates are also clipped to a circle, so a square,
     top-down photo of a round plate on a dark background works too.
   - See ASSETS.md for the full list, sizes and sourcing rules.
   ===================================================================== */

window.SITE = {
  restaurant: {
    name: "Olive & Thyme",
    city: "Sargodha",
    addressLines: ["Avenue 51 Katchrey Road", "Awan Colony", "Sargodha 40100, Pakistan"],
    addressOneLine: "Avenue 51 Katchrey Road, Awan Colony, Sargodha, 40100, Pakistan",
    phoneDisplay: "+92 311 1333722",
    phoneHref: "tel:+923111333722",
    tagline: "Crafted with passion",
    services: ["Dine-in", "Takeaway"],

    // Leave WhatsApp empty until the number is confirmed to support WhatsApp.
    // Example once confirmed: "https://wa.me/923111333722"
    whatsappHref: "",

    // Add social links only when you have them, e.g.
    // { label: "Instagram", href: "https://instagram.com/yourhandle" }
    social: [],

    // Opening hours are intentionally NOT shown until confirmed.
    // When confirmed, add rows like { days: "Mon – Thu", time: "12 pm – 11 pm" }
    hours: []
  },

  /* ---------------------------------------------------------------
     MENU
     sample: true shows a "Sample menu" label on the website.
     Set it to false once the real menu below has been entered.
     Prices are optional: add  price: "Rs 1,250"  to any item.
     --------------------------------------------------------------- */
  menu: {
    sample: true,
    note: "Our full menu is being finalised. Please call us for today's selection.",
    categories: [
      {
        title: "Starters & Salads",
        kicker: "To begin",
        image: { src: "assets/images/menu-salads.webp", alt: "Illustrative photo of a plated dish (stock)", cutout: true },
        items: [
          { name: "Sample starter", desc: "Dish name and description to be confirmed." },
          { name: "Sample salad", desc: "Dish name and description to be confirmed." }
        ]
      },
      {
        title: "Mains",
        kicker: "From the kitchen",
        image: { src: "assets/images/menu-mains.webp", alt: "Illustrative photo of a main course (stock)", cutout: true },
        items: [
          { name: "Sample main course", desc: "Dish name and description to be confirmed." },
          { name: "Sample main course", desc: "Dish name and description to be confirmed." }
        ]
      },
      {
        title: "From the Grill",
        kicker: "Fire & flavour",
        image: { src: "assets/images/menu-grill.webp", alt: "Illustrative photo of a grilled dish (stock)", cutout: true },
        items: [
          { name: "Sample grill", desc: "Dish name and description to be confirmed." },
          { name: "Sample grill", desc: "Dish name and description to be confirmed." }
        ]
      },
      {
        title: "Pasta",
        kicker: "Comfort, plated",
        image: { src: "assets/images/menu-pasta.webp", alt: "Illustrative photo of a pasta dish (stock)", cutout: true },
        items: [
          { name: "Sample pasta", desc: "Dish name and description to be confirmed." },
          { name: "Sample pasta", desc: "Dish name and description to be confirmed." }
        ]
      }
    ]
  },

  /* ---------------------------------------------------------------
     PHOTOS
     Story, experience and gallery use ORIGINAL Olive & Thyme photos.
     Food plates are temporary stock photos (Unsplash) — see ASSETS.md.
     --------------------------------------------------------------- */
  images: {
    logo:       { src: "assets/images/logo.png",        alt: "Olive & Thyme — Crafted with passion" },
    heroDish:   { src: "assets/images/hero-dish.webp",  alt: "Illustrative photo of a plated salad (stock)", cutout: true },
    heroSide:   { src: "", alt: "", cutout: true },        // optional small bowl (transparent PNG)
    herbs: [                                              // optional transparent herb cut-outs
      { src: "", alt: "" }, { src: "", alt: "" }, { src: "", alt: "" }
    ],
    story:      { src: "assets/images/story.jpg",        alt: "A set table in the Olive & Thyme dining room, with green placemats and mustard chairs" },
    storyDetail:{ src: "assets/images/story-detail.jpg", alt: "Glassware and a folded napkin on a green placemat" },
    experience: { src: "assets/images/experience.jpg",   alt: "The Olive & Thyme storefront at night, with the illuminated sign and dining room" },
    gallery: [
      { src: "assets/images/gallery-1.jpg", alt: "Olive & Thyme storefront and two-level dining room at night" },
      { src: "assets/images/gallery-2.jpg", alt: "The round illuminated Olive & Thyme sign" },
      { src: "assets/images/gallery-3.jpg", alt: "Botanical arch wall and mustard chairs inside Olive & Thyme" },
      { src: "assets/images/gallery-4.jpg", alt: "The Olive & Thyme logo mounted on a wall" },
      { src: "assets/images/gallery-5.jpg", alt: "Table setting with dried flowers at Olive & Thyme" }
    ]
  }
};
