/* Olive & Thyme — rendering + motion (no dependencies) */
(function () {
  "use strict";
  document.documentElement.classList.remove("no-js");
  var S = window.SITE || {};
  var R = S.restaurant || {};
  var IMG = S.images || {};
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var finePointer = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var svgUse = function (id, cls) { return '<svg class="' + (cls || "") + '" aria-hidden="true" focusable="false"><use href="#' + id + '"/></svg>'; };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };

  /* ---------------- content binding ---------------- */
  var mapsHref = "https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent(R.addressOneLine || "");
  var binds = {
    city: R.city,
    tagline: R.tagline,
    services: (R.services || []).join(" & "),
    phoneDisplay: R.phoneDisplay,
    menuNote: S.menu && S.menu.note,
    phoneHref: R.phoneHref,
    mapsHref: mapsHref,
    whatsappHref: R.whatsappHref
  };
  $$("[data-bind]").forEach(function (el) {
    var key = el.getAttribute("data-bind");
    if (/Href$/.test(key)) {
      var v = binds[key];
      if (!v) { if (el.hasAttribute("data-hide-empty")) el.remove(); return; }
      el.setAttribute("href", v);
      if (key === "phoneHref" && !el.getAttribute("aria-label") && /Call/.test(el.textContent)) el.setAttribute("aria-label", el.textContent.trim() + " at " + R.phoneDisplay);
    } else if (key === "addressLines") {
      el.innerHTML = (R.addressLines || []).map(function (l) { return '<span class="br">' + esc(l) + "</span>"; }).join("");
    } else if (key === "hours") {
      el.innerHTML = (R.hours || []).map(function (h) { return '<span class="br">' + esc(h.days) + " · " + esc(h.time) + "</span>"; }).join("");
    } else if (key === "social") {
      if (!(R.social || []).length) { el.remove(); return; }
      el.innerHTML = R.social.map(function (s) { return '<li><a href="' + esc(s.href) + '" target="_blank" rel="noopener">' + esc(s.label) + "</a></li>"; }).join("");
    } else if (binds[key] != null) {
      el.textContent = binds[key];
    }
  });
  var showIf = { menuSample: !!(S.menu && S.menu.sample), hours: !!(R.hours || []).length };
  $$("[data-show-if]").forEach(function (el) { var k = el.getAttribute("data-show-if"); if (k in showIf && !showIf[k]) el.remove(); });
  var y = $("#year"); if (y) y.textContent = new Date().getFullYear();

  /* ---------------- menu ---------------- */
  var menuList = $("#menu-list");
  if (menuList && S.menu) {
    menuList.innerHTML = S.menu.categories.map(function (c, i) {
      var items = (c.items || []).map(function (it) {
        return '<li><div class="mi-top"><span class="mi-name">' + esc(it.name) + "</span>" +
          (it.price ? '<span class="mi-dots" aria-hidden="true"></span><span class="mi-price">' + esc(it.price) + "</span>" : "") +
          "</div>" + (it.desc ? '<p class="mi-desc">' + esc(it.desc) + "</p>" : "") + "</li>";
      }).join("");
      return '<article class="menu-row" style="--dir:' + (i % 2 ? 1 : -1) + '">' +
        '<div class="menu-media"><figure class="plate" data-slot="menu.' + i + '"></figure>' +
        '<div class="orn" aria-hidden="true">' + svgUse("thyme") + "</div></div>" +
        '<div class="menu-copy"><p class="kicker rv">' + esc(c.kicker || "") + '</p><h3 class="rv" style="--i:1">' + esc(c.title) + "</h3>" +
        '<ul class="menu-items rv" style="--i:2">' + items + "</ul></div></article>";
    }).join("");
  }

  /* ---------------- gallery ---------------- */
  var gal = $("#gal-grid");
  if (gal) {
    gal.innerHTML = (IMG.gallery || []).map(function (g, i) {
      return '<figure class="gal-item frame rv rv--img" style="--i:' + (i % 3) + '" data-slot="gallery.' + i + '"></figure>';
    }).join("");
  }

  /* ---------------- image slots ----------------
     Each slot loads its file; if it is missing the slot falls back to an
     on-brand placeholder (frames, plates) or hides (decorative layers). */
  function getImg(path) {
    if (path.indexOf("menu.") === 0) { var c = S.menu.categories[+path.split(".")[1]]; return c && c.image; }
    return path.split(".").reduce(function (o, k) { return o ? o[k] : null; }, IMG);
  }
  var galleryState = { loaded: 0, failed: 0, total: (IMG.gallery || []).length };
  function galleryDone() {
    if (galleryState.loaded + galleryState.failed < galleryState.total) return;
    var note = $(".gal-note");
    if (galleryState.loaded > 0) {
      if (note) note.remove();
      $$(".gal-item.is-empty").forEach(function (e) { e.remove(); });
    }
  }
  $$("[data-slot]").forEach(function (el) {
    var key = el.getAttribute("data-slot");
    var data = getImg(key);
    var isPlate = el.classList.contains("plate");
    var isFrame = el.classList.contains("frame");
    var isGal = key.indexOf("gallery.") === 0;
    var host = el;
    if (isPlate) { host = document.createElement("div"); host.className = "plate-inner"; el.appendChild(host); }

    function fail() {
      el.classList.add("is-empty");
      host.innerHTML = "";
      if (isFrame) host.innerHTML = '<span class="mono">' + svgUse("mono") + "</span>";
      if (isPlate) host.innerHTML = '<span class="plate-orn">' + svgUse("thyme") + '</span><span class="plate-orn">' + svgUse("thyme") + "</span>";
      if (isFrame || isPlate) el.setAttribute("aria-hidden", "true");
      if (isGal) { galleryState.failed++; galleryDone(); }
    }
    if (!data || !data.src) { fail(); return; }
    var img = new Image();
    img.decoding = "async";
    img.alt = data.alt || "";
    if (isFrame) img.className = "slot-img";
    var inHero = !!el.closest(".hero");
    if (!inHero) img.loading = "lazy";
    if (inHero && key === "heroDish") img.fetchPriority = "high";
    if (data.cutout && /\.(png|webp|avif)$/i.test(data.src)) el.classList.add("is-cut");
    img.onload = function () { if (isGal) { galleryState.loaded++; galleryDone(); } };
    img.onerror = fail;
    img.src = data.src;
    host.appendChild(img);
  });

  /* ---------------- hero specks (fine "flour dust", as in the reference) ---------------- */
  var specks = $(".specks");
  if (specks) {
    var seed = 9, rnd = function () { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    var html = "";
    for (var i = 0; i < 150; i++) {
      var a = rnd() * Math.PI * 2, d = 30 + Math.pow(rnd(), 0.7) * 22;
      var s = (rnd() * 2.6 + 0.8).toFixed(1);
      var col = rnd() < 0.35 ? "#9a8148" : (rnd() < 0.5 ? "#5d6e2a" : "#82953c");
      html += '<i style="left:' + (50 + Math.cos(a) * d).toFixed(2) + "%;top:" + (50 + Math.sin(a) * d).toFixed(2) + "%;width:" + s + "px;height:" + s + "px;--c:" + col + ";opacity:" + (rnd() * 0.6 + 0.2).toFixed(2) + '"></i>';
    }
    specks.innerHTML = html;
  }

  /* ---------------- reveals ---------------- */
  var rvs = $$(".rv");
  if ("IntersectionObserver" in window && !reduce) {
    // Image reveals start fully clipped, which IntersectionObserver reports as
    // invisible, so those are triggered by their (unclipped) parent instead.
    var groups = new Map();
    rvs.forEach(function (el) {
      var t = el.classList.contains("rv--img") ? el.parentElement : el;
      if (!groups.has(t)) groups.set(t, []);
      groups.get(t).push(el);
    });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        (groups.get(e.target) || []).forEach(function (el) { el.classList.add("is-in"); });
        io.unobserve(e.target);
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.05 });
    groups.forEach(function (_, t) { io.observe(t); });
  } else {
    rvs.forEach(function (el) { el.classList.add("is-in"); });
  }

  /* ---------------- header + nav ---------------- */
  var header = $(".site-header");
  var toggle = $(".nav-toggle"), nav = $("#site-nav");
  function setNav(open) {
    toggle.setAttribute("aria-expanded", String(open));
    toggle.querySelector(".sr").textContent = open ? "Close menu" : "Open menu";
    nav.classList.toggle("is-open", open);
    document.body.classList.toggle("nav-open", open);
    if (open) { var f = nav.querySelector("a"); f && f.focus(); }
  }
  toggle.addEventListener("click", function () { setNav(toggle.getAttribute("aria-expanded") !== "true"); });
  nav.addEventListener("click", function (e) { if (e.target.closest("a") && nav.classList.contains("is-open")) setNav(false); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && nav.classList.contains("is-open")) { setNav(false); toggle.focus(); }
    if (e.key === "Tab" && nav.classList.contains("is-open")) {         // keep focus inside the open menu
      var f = $$("a", nav).concat([toggle]), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  var links = $$(".nav ul a");
  if ("IntersectionObserver" in window) {
    var secIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) return;
        var id = e.target.id === "experience" ? "story" : e.target.id;
        links.forEach(function (a) {
          var on = a.getAttribute("href") === "#" + id;
          a.classList.toggle("is-active", on);
          if (on) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    $$("main section[id]").forEach(function (s) { secIO.observe(s); });
  }

  /* ---------------- motion engine ---------------- */
  var hero = $(".hero"), heroVisual = $(".hero-visual"), stage = $(".stage");
  var heroPlate = $(".plate--hero .plate-inner");
  var depthEls = [], rows = [];
  var vh = window.innerHeight, smooth = window.scrollY, mobile = false;

  function absTop(el) { var t = 0; while (el) { t += el.offsetTop; el = el.offsetParent; } return t; }
  function measure() {
    vh = window.innerHeight;
    mobile = window.innerWidth < 980;
    depthEls = $$("[data-depth]").map(function (el) {
      return { el: el, top: absTop(el), h: el.offsetHeight, d: parseFloat(el.getAttribute("data-depth")) || 0 };
    });
    rows = $$(".menu-row").map(function (el) { return { el: el, top: absTop(el), h: el.offsetHeight, p: -1 }; });
  }

  var heroVisible = true;
  if (hero && "IntersectionObserver" in window) {
    new IntersectionObserver(function (e) { heroVisible = e[0].isIntersecting; hero.classList.toggle("is-paused", !heroVisible); }).observe(hero);
  }

  var lastY = -1;
  function frame() {
    var target = window.scrollY;
    smooth += (target - smooth) * (mobile ? 0.25 : 0.14);
    if (Math.abs(target - smooth) < 0.05) smooth = target;
    var yv = smooth;

    if (header) header.classList.toggle("is-scrolled", target > 30);

    if (yv !== lastY) {
      lastY = yv;
      var k = mobile ? 0.45 : 1;
      for (var i = 0; i < depthEls.length; i++) {
        var o = depthEls[i];
        var center = o.top + o.h / 2 - yv - vh / 2;
        if (center > vh * 1.6 || center < -vh * 1.6) continue;
        o.el.style.setProperty("--py", (-center * o.d * k).toFixed(1) + "px");
      }
      for (var j = 0; j < rows.length; j++) {
        var r = rows[j];
        var p = Math.min(1, Math.max(0, (vh - (r.top - yv)) / (vh * 0.62)));
        p = 1 - Math.pow(1 - p, 3);
        if (Math.abs(p - r.p) > 0.001) { r.p = p; r.el.style.setProperty("--p", p.toFixed(3)); }
      }
      if (heroPlate && heroVisible) heroPlate.style.setProperty("--spin", Math.min(yv * 0.035, 30).toFixed(2) + "deg");
    }
    requestAnimationFrame(frame);
  }

  /* mouse-responsive perspective tilt (desktop only) */
  if (heroVisual && finePointer && !reduce) {
    hero.addEventListener("pointermove", function (e) {
      var b = heroVisual.getBoundingClientRect();
      var nx = (e.clientX - (b.left + b.width / 2)) / (b.width / 2);
      var ny = (e.clientY - (b.top + b.height / 2)) / (b.height / 2);
      nx = Math.max(-1, Math.min(1, nx)); ny = Math.max(-1, Math.min(1, ny));
      stage.style.setProperty("--ry", (nx * 7).toFixed(2) + "deg");
      stage.style.setProperty("--rx", (-ny * 6).toFixed(2) + "deg");
    });
    hero.addEventListener("pointerleave", function () { stage.style.setProperty("--rx", "0deg"); stage.style.setProperty("--ry", "0deg"); });
  }

  if (!reduce) {
    measure();
    window.addEventListener("resize", function () { clearTimeout(window.__mt); window.__mt = setTimeout(function () { measure(); lastY = -1; }, 120); });
    window.addEventListener("load", function () { measure(); lastY = -1; });
    requestAnimationFrame(frame);
  } else {
    window.addEventListener("scroll", function () { header.classList.toggle("is-scrolled", window.scrollY > 30); }, { passive: true });
  }
})();
