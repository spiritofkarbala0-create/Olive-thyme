# Olive & Thyme: website

An animated, single-page restaurant website for Olive & Thyme, Sargodha.
It is plain HTML, CSS and JavaScript with **no build step and no dependencies**, so it is fast, easy to host and easy to edit.

## Project structure

```
olive-and-thyme/
├── index.html              Page structure and section copy
├── assets/
│   ├── js/content.js       ← EDIT THIS: details, menu, photo paths
│   ├── js/main.js          Rendering + animation engine
│   ├── css/styles.css      Design system and layout
│   ├── fonts/              Self-hosted Lora + Poppins (SIL Open Font Licence)
│   ├── images/             ← PUT PHOTOS HERE (see ASSETS.md)
│   └── favicon.svg
├── vercel.json             Hosting headers / caching
├── ASSETS.md               Photo list, sizes and sourcing rules
└── README.md
```

## Run it locally

Any static file server works. From the project folder:

```bash
# Option 1: Python (installed on most computers)
python3 -m http.server 8080
# Option 2: Node
npx serve .
```

Then open http://localhost:8080. Double-clicking `index.html` also mostly works, but some browsers block the fonts on `file://`, so a server is better.

## Deploy to Vercel

**Without Git (quickest):**
1. Install the CLI: `npm i -g vercel`
2. In the project folder, run `vercel`, then accept the defaults (Framework: *Other*, no build command, output directory `.`).
3. Run `vercel --prod` to publish.

**With GitHub:**
1. Push this folder to a GitHub repository.
2. On vercel.com, click **Add New → Project** and import the repo.
3. Framework preset: **Other**. Leave Build Command and Output Directory empty. Click **Deploy**.

Every later push redeploys automatically. To add a custom domain, go to Vercel → Project → Settings → Domains.

## Editing content

Everything changeable lives in **`assets/js/content.js`**:

- **Phone, address, services:** the `restaurant` block. The Call buttons and the Google Maps directions link update automatically.
- **Menu:** `menu.categories`. Add or remove categories and items freely; `price` is optional per item. Set `menu.sample` to `false` once the real menu is entered, which removes the "Sample menu" label.
- **Opening hours, WhatsApp, social links:** empty on purpose. Fill them in and they appear on the site.
- **Photos:** drop files into `assets/images/` with the names listed in `ASSETS.md`. Missing photos show a styled placeholder rather than a broken image.

Section headings and paragraph copy are in `index.html`.

## Animation and accessibility notes

- Parallax depth layers, staggered reveals, plates that move into position on scroll, a gentle hero float and a mouse-responsive 3D tilt (desktop only). These are simulated with layered CSS transforms; there are no 3D models.
- Native scrolling is never hijacked. The Experience heading uses a light CSS `position: sticky` pin on desktop.
- `prefers-reduced-motion` turns off parallax, float, tilt and slide-ins; content simply appears.
- On mobile, parallax depth is reduced and tilt is disabled.
- Skip link, visible focus rings, keyboard-operable mobile menu (Esc closes it, focus stays inside), `aria-current` on the active nav item, and AA-contrast text.
- Images below the fold are lazy-loaded, and all image slots have fixed aspect ratios, so nothing shifts while loading.

## Why not React / GSAP?

The brief allowed "an equally suitable lightweight setup". Vanilla JS gives the same scroll-linked parallax and reveals with zero dependencies, no build step and a smaller download. If you later want React, the content model in `content.js` maps directly onto components.
